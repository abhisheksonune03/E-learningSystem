package com.E.learning.entities;
import java.sql.*;

//for creation of registration page we required some variables (attributes) thats are below 
public class User {
	private int id;
	private int update;
	private String name;
	private String email;
	private String password;
	private String gender;
	private String profile;
    
   

	
	public String getProfile() {
		return profile;
	}
	public void setProfile(String profile) {
		this.profile = profile;
	}
	//parameterized constructor
	public User(int id, String name, String email, String password, String gender) {
		this.id = id;
		this.name = name;
		this.email = email;
		this.password = password;
		this.gender = gender;
	}
	//non parameterized constructor
	public User() {
		
	}
	public User(String name, String email, String password, String gender) {
		
		this.name = name;
		this.email = email;
		this.password = password;
		this.gender = gender;
	}
	//getter and setter methods
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	

	
	public int getUpdate() {
		return update;
	}
	public void setUpdate(int update) {
		this.update = update;
	}

	

}
