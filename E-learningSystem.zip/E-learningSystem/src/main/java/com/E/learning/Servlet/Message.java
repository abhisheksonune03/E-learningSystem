package com.E.learning.Servlet;

public class Message {
 private String msg;
 private String diff;
 private String css;
public Message(String msg, String diff, String css) {
	super();
	this.msg = msg;
	this.diff = diff;
	this.css = css;
}
public String getMsg() {
  return msg;
}
public void setMsg(String msg) {
	this.msg = msg;
}
public String getdiff() {
	return diff;
}
public void setDif(String diff) {
	this.diff = diff;
}
public String getCss() {
	return css;
}
public void setCss(String css) {
	this.css = css;
}

}
