 package com.E.learning.Servlet;




	import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;

	import jakarta.servlet.http.HttpServlet;
	import jakarta.servlet.http.HttpServletRequest;
	import jakarta.servlet.http.HttpServletResponse;
	import jakarta.servlet.http.HttpSession;
import jakarta.servlet.jsp.JspWriter;

import com.E.learning.helper.*;
import com.E.learning.Userdao.Userdao;
import com.E.learning.Userdao.feedbackdao;
import com.E.learning.entities.*;
import com.E.learning.entities.feedback.*;

	
	@MultipartConfig
	public class submitFeedbackServlet extends HttpServlet {

		public void doPost(HttpServletRequest request, HttpServletResponse response)
				throws ServletException, IOException {
			if(request.getParameter("b1").equals("Add"))
			{
				feedback f=new feedback();
				
				f.setName(request.getParameter("name"));
				f.setEmail(request.getParameter("email"));
				f.setFeedback(request.getParameter("feedback"));
				
				if(new feedbackdao().savefeedback(f)>0)
				{
					request.getRequestDispatcher("index.jsp").forward(request, response);
				}
			}
			
		}
				
			
		
		public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			// TODO Auto-generated method stub
			doPost(request, response);
		}


	}


