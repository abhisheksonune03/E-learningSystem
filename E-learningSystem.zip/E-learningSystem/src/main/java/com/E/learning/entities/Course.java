package com.E.learning.entities;

import java.sql.Blob;
import java.sql.Date;

public class Course {
	 private String course_name; 
	 private  String c_description; 
	 private  String c_resourse;
    private double c_fees;
	private int CourseId ;

	public Course() {
		
	}

	public Course( int  CourseId,String course_name, String c_description, double c_fees, String c_resourse) {
		super();
		this.course_name = course_name;
		this.c_description = c_description;
		this.c_fees = c_fees;
		this.c_resourse = c_resourse;
		this.CourseId =CourseId ;
	}

	public int getCourseId() {
		return CourseId;
	}

	public void setCourseId(int CourseId ) {
		this.CourseId  = CourseId ;
	}

	public void setCourse_name(String course_name) {
		this.course_name = course_name;
	}
	public String getCourse_name() {
		return course_name;
	}
	public String getC_description() {
		return c_description;
	}

	public void setC_description( String c_description) {
		this.c_description = c_description;
	}

	public double getC_fees() {
		return c_fees;
	}

	public void setC_fees(double c_fees ) {
		this.c_fees = c_fees;
	}

	public String getC_resourse() {
		return c_resourse;
	}

	public void setC_resourse(String c_resourse ) {
		this.c_resourse=c_resourse;
		
	}

}

