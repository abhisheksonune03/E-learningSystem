package com.E.learning.Servlet;



import java.io.IOException;


import java.io.PrintWriter;


import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import com.E.learning.helper.*;
import com.E.learning.entities.Admin;
import com.E.learning.entities.User;
import com.E.learning.entities.Admin.*;
import com.E.learning.Userdao.Admindao;
import com.E.learning.Userdao.Userdao;
import com.E.learning.Userdao.Admindao.*;


@MultipartConfig
public class AdminLogin extends HttpServlet {
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw=response.getWriter();
	String check=request.getParameter("check");
		
		if(check==null)
		{
			pw.println("please check the terms and conditions");
		}else {
		String email = request.getParameter("email");
		String password = request.getParameter("password");
	
	
    
 	Admin ad=new Admin(email,password);
	
	Admindao dao=new Admindao(ConnectionProvider.getConnection()); 
	if(dao.saveAdmin(ad)) {
		
		pw.println("done");
	}
	else {
		pw.println("error");
	}
}
	
	}
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

}
