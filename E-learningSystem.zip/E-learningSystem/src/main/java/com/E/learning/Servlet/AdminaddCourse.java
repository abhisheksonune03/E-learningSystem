 package com.E.learning.Servlet;

import java.io.File;

 
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import com.E.learning.Userdao.*;
	import com.E.learning.entities.*;
	import com.E.learning.helper.*;
import jakarta.servlet.ServletException;
	import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
	import jakarta.servlet.http.HttpServletRequest;
	import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

//@WebServlet("/Admin-add-user")
// the place of @multiconfig is fixed if we changed the place then we will get  denger headcatch
@MultipartConfig
	public class AdminaddCourse extends HttpServlet {
		
		public void doPost(HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException {
			
			PrintWriter pw=response.getWriter();
		
			//int CourseId=Integer.parseInt(request.getParameter("fe"));
			String course_name=request.getParameter("courseName");
				String c_description=request.getParameter("description");
				int c_fees=Integer.parseInt(request.getParameter("fees"));
				
				Part filepart=request.getPart("resourse");
			Course course1=new Course();
			course1.setCourse_name(course_name);
			course1.setC_description(c_description);
			course1.setC_fees(c_fees);
		
			course1.setC_resourse(filepart.getSubmittedFileName());
			AddCoursedao dao1=new AddCoursedao(ConnectionProvider.getConnection());
		dao1.saveCourse(course1);
					String path=request.getRealPath("img")+File.separator+"course"+File.separator+filepart.getSubmittedFileName();
	        System.out.println(path);
	              
	          	try {
	              		//fileoutstream is userfull for write 
					FileOutputStream fos=new FileOutputStream(path);
					//fileinputstream is usefull for read 
					InputStream is=filepart.getInputStream();
				//reading data
				
						
					
					byte[]data=new byte[is.available()];
					is.read(data);
					fos.write(data);
					fos.close();
					pw.println("done");
				
					}catch(Exception e) {
						e.printStackTrace();
					}
			}
			
		


		public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
			doPost(request, response);
		}

	}