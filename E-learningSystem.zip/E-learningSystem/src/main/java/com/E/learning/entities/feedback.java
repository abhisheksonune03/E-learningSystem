package com.E.learning.entities;

public class feedback {

	private String name;
	private String email;
	private String feedback;
 
	
	public feedback() {
		
	}

	public feedback(String name, String email, String feedback) {
		
		this.name = name;
		this.email = email;
		this.feedback = feedback;
	}

	public void setName(String name) {
		// TODO Auto-generated method stub
		this.name=name;
	}

	public String getName() {
		// TODO Auto-generated method stub
		return name;
	}
	

	public void setEmail(String email) {
		// TODO Auto-generated method stub
		this.email=email;
	}

	public String getEmail() {
		// TODO Auto-generated method stub
		return email;
	}

	public void setFeedback(String feedback) {
		// TODO Auto-generated method stub
		this.feedback=feedback;
	}

	public String getFeedback() {
		// TODO Auto-generated method stub
		return feedback;
	}

}
