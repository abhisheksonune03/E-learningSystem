package com.E.learning.entities;

public class cart  extends Course{
   private int quantity;

public cart(int quantity) {

	this.quantity = quantity;
}
public cart() {
	
}
public int getQuantity() {
	return quantity;
}
public void setQuantity(int quantity) {
	this.quantity = quantity;
}
}
