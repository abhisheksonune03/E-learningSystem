package com.E.learning.Userdao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.E.learning.entities.Admin;
import com.E.learning.entities.User; 
public class Admindao {
	private  Connection con;

	public Admindao(Connection con) {
		 
		this.con = con;
	} 
	public boolean saveAdmin(Admin ad1) {
		boolean f=false;
		try {
			String query="insert into abhi(email, password) values(?,?)";
			PreparedStatement ps=this.con.prepareStatement(query);
		
			ps.setString(1, ad1.getEmail());
			ps.setString(2, ad1.getPassword());
	
			//ps.setString(4, user.getProfile());
			
			ps.executeUpdate();
			f=true;
		}catch(Exception e) {
			e.printStackTrace();
		}
		return f;
	}
	public   Admin getAdminByEmailAndPassword(String email,String password ) {
		Admin ad1=null;
		try {
			String query=("Select *  FROM abhi where email=? AND password=?");
			PreparedStatement ps =con.prepareStatement(query);
			ps.setString(1, email);
			ps.setString(2, password);
		
			ResultSet set=ps.executeQuery();
			
			if(set.next()) {
			ad1=new Admin();
			
				ad1.setEmail(set.getString("email"));
		 		ad1.setPassword(set.getString("password"));
			
				
			}
		}catch(Exception e) {
			e.printStackTrace();
			
			} 
			
		return ad1; 
		
		}
	

	}


