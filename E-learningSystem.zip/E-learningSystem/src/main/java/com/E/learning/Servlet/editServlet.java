package com.E.learning.Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import com.E.learning.Servlet.*;
import com.E.learning.Userdao.Userdao;
import com.E.learning.entities.User;
import com.E.learning.helper.ConnectionProvider;

import jakarta.servlet.http.Part;
/**
 * Servlet implementation class editServlet
 */ 
@MultipartConfig
public class editServlet extends HttpServlet {

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	PrintWriter pw=response.getWriter();
	
	String userName=request.getParameter("user_name");
	String userEmail=request.getParameter("user_email");
	String userPassword=request.getParameter("user_password");
	Part part=request.getPart("img");
	String imgName=part.getSubmittedFileName();
	
	
	
	 HttpSession s= request.getSession();
	 User user=(User) s.getAttribute("currentUser");
	 user.setName(userName);
	 user.setEmail(userEmail);
	 user.setPassword(userPassword);
	 user.setProfile(imgName);
	 Userdao userdao=new Userdao(ConnectionProvider.getConnection());

	
	 boolean ab = userdao.updateUser(user);
	
	   if(ab) {
		   pw.println("Updated into ther database");
	   }else {
		   pw.println("data not updated");
	   }
	}
	
	
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
