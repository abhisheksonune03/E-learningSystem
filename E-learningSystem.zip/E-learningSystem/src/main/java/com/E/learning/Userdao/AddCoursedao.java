package com.E.learning.Userdao;


import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import javax.management.Query;

import com.E.learning.entities.Course;
import com.E.learning.entities.User;
import com.E.learning.entities.cart;

import jakarta.websocket.Session;
import oracle.jdbc.OracleResultSet; 

public class AddCoursedao{
	
private  Connection con;

public AddCoursedao(Connection con) {
	 
	this.con = con;
} 



public AddCoursedao(  String course_name, String c_description, String c_fees, String c_resourse) {
	// TODO Auto-generated constructor stub
}



public boolean saveCourse(Course course1) {
	boolean f=false;

	try {
		String query="insert into Course1(  CourseId ,Course_name,C_description,C_fees,C_resourse) values(?,?,?,?,?)";
		PreparedStatement ps=this.con.prepareStatement(query);
		ps.setInt(1,course1.getCourseId() );	
		ps.setString(2, course1.getCourse_name());
		ps.setString(3, course1. getC_description());
		ps.setDouble(4, course1.getC_fees());
		ps.setString(5, course1.getC_resourse());
		//ps.setString(4, user.getProfile());
		//Session s=this.con.OpenSession();
		ps.executeUpdate();
		f=true;
	}catch(Exception e) {
		e.printStackTrace();
	
	}
	return f;
	}
 /*public   Course  getCourseByCourse_nameAndC_descriptionANDC_feesANDC_resourse( String Course_name, String c_description, String c_fees, String c_resourse) {
	Course  course=null;

	try {
		String query=("Select * FROM  Course1  where Course_name=? AND C_description=? AND C_fees=? AND C_resourse=?");
		PreparedStatement ps =con.prepareStatement(query);
		ps.setString(1,Course_name);
		ps.setString(2, c_description);
		ps.setString(3, c_fees);
		ps.setString(4,c_resourse);
		ResultSet set=ps.executeQuery();
	
		if(set.next()) {
			course =new Course();
			String course_name=set.getString("course_name");
			course.setCourse_name(course_name);
			course.setC_description(set.getString("c_description"));
			course.setC_fees(set.getInt(" c_fees"));
			course.setC_resourse(set.getString("c_resourse"));
		
		
		}
	}catch(Exception e) {
		e.printStackTrace();
		
		} 

    return course; 


}*/
public List<Course>getAllCourse(){
	List<Course>Course=new ArrayList<Course>();
	try {
		 String query="Select * FROM  Course1 ";
		 PreparedStatement  ps =this.con.prepareStatement(query);
		 ResultSet rs=ps.executeQuery();
		 while(rs.next()) {
			 Course co=new Course();
			 co.setCourseId(rs.getInt("CourseId"));
			 co.setCourse_name(rs.getString("course_name"));
			 co.setC_description(rs.getString("c_description"));
			 co.setC_fees(rs.getDouble("c_fees"));
			 co.setC_resourse(rs.getString("c_resourse"));
			 Course.add(co);
		 }
		  
	}catch(Exception e)
	{
		e.printStackTrace();;
	}
	return Course;
	
}
 
public List<cart>getCartCourse(ArrayList<cart>cartList){
	List<cart>Course=new ArrayList<cart>();
	
	
	try {
		if(cartList.size()>0) {
			for(cart item: cartList) {
				String query="select * from Course1 where CourseId=?";
				PreparedStatement ps=this.con.prepareStatement(query);
				ps.setInt(1, item.getCourseId());
				 ResultSet rs=ps.executeQuery();
				 while(rs.next()) {
					 cart row=new cart();
					 row.setCourseId(rs.getInt("CourseId"));
					 row.setCourse_name(rs.getString("course_name"));
					 row.setC_description(rs.getString("c_description"));
					 row.setC_fees(rs.getDouble("c_fees")*item.getQuantity());
					 row.setQuantity(item.getQuantity());
					 Course.add(row);
				 }
			}
		}
		
	}catch(Exception e) {
		System.out.println(e.getMessage());
		//e.printStackTrace();
	}
	return Course;
}
public double getTotalCartPrice(ArrayList<cart>cartList) {
	double sum=0;
	try {
		if(cartList.size()>0) {
			for(cart item:cartList) {
		String query="select c_fees  from Course1 where CourseId=?";
		PreparedStatement ps=this.con.prepareStatement(query);
		ps.setInt(1, item.getCourseId() );
		ResultSet rs=ps.executeQuery();
		 while(rs.next()) {
			 
		 sum+=rs.getDouble("c_fees")+ item.getQuantity();
		 
		 }
		}
	}
	}catch(Exception e) {
		
	}
	return sum;
}
};
	



