package com.E.learning.Servlet;

	import java.io.IOException;



	import java.io.PrintWriter;

    import com.E.learning.Userdao.Admindao;
  // import com.E.learning.Userdao.Userdao;
import com.E.learning.entities.Admin;
//import com.E.learning.entities.User;
import com.E.learning.helper.ConnectionProvider;
	import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.http.HttpServlet;
	import jakarta.servlet.http.HttpServletRequest;
	import jakarta.servlet.http.HttpServletResponse;
	import jakarta.servlet.http.HttpSession;


	/**
	 * Servlet implementation class LoginServlet
	 */
	@MultipartConfig
	public class AdminLoginServlet extends HttpServlet {

	   
		//private Object String;
		public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			PrintWriter pw=response.getWriter();
	 		
			String AdminEmail=request.getParameter("email");
			String AdminPassword=request.getParameter("password");
			Admindao dao=new Admindao(ConnectionProvider.getConnection());  
			Admin ad=dao.getAdminByEmailAndPassword(AdminEmail,AdminPassword);
			 
			HttpSession httpsession=request.getSession();
			
			if(ad==null) {
			   //  pw.println("invalid credential ...please Try again");
		httpsession.setAttribute("message","invalid credential ...please Try again" );
			response.sendRedirect("index.jsp");
			return;
			}else {
        	 pw.println("<h1>welcome"+ad.getEmail()+"</h1>");
        	 httpsession.setAttribute("current-admin",ad);
				response.sendRedirect("admin-add-courses.jsp");
			}
			pw.close(); 
		}
		public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			// TODO Auto-generated method stub
			doPost(request, response);
		}

	}

