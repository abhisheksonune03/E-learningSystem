package com.E.learning.Servlet;

import java.io.IOException;

import java.io.PrintWriter;
import com.E.learning.Userdao.*;
import com.E.learning.entities.*;
import com.E.learning.helper.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

// the place of @multiconfig is fixed if we changed the place then we will get  danger headache

@MultipartConfig 
public class RegisterServlet extends HttpServlet {
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter pw=response.getWriter();
		String check=request.getParameter("check");
		
		if(check==null)
		{
			pw.println("please check the terms and conditions");
		}
		else {
		
			String name=request.getParameter("user_name");
			String email=request.getParameter("user_email");
			String password=request.getParameter("user_password");
		     String gender=request.getParameter("gender");
			
			//creating user object
			User user=new User(name,email,password,gender);
			
			Userdao dao=new Userdao(ConnectionProvider.getConnection());
			if(dao.saveUser(user)) {
				
				pw.println("done");
			}
			else {
				pw.println("error");
			}
		}
		
	}


	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doPost(request, response);
	}

}
