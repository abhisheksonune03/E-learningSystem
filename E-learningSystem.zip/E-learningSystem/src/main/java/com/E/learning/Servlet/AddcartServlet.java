package com.E.learning.Servlet;

import java.io.IOException;

import java.io.PrintWriter;
import java.util.ArrayList;

import com.E.learning.entities.cart;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
//import jakarta.servlet.annotation.MultipartConfig;


public class AddcartServlet extends HttpServlet {
	
   
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	
	 
		 PrintWriter pw=response.getWriter(); 
		 //we create a method for fatching a data dynamically
		 ArrayList<cart>cartList=new ArrayList<>();
		 int CourseId=Integer.parseInt(request.getParameter("CourseId"));
	//	 String course_name =request.getParameter("course_name");
		 cart ct=new cart();
		 ct.setCourseId(CourseId);
		 ct.setQuantity(1);
		 HttpSession session=request.getSession();
		 
		  ArrayList<cart>cart_list= (ArrayList<cart>) session.getAttribute("cart-list");
		  
		  
		  if(cart_list==null) {
			  cartList.add(ct);
			  session.setAttribute("cart-list",cartList);
			  response.sendRedirect("course.jsp");
		  }
		  else {
			  
			  cartList=cart_list;
			  boolean d=false;
			  cartList.contains(ct);
			  for(cart c:cartList) {
				if(c.getCourseId()==CourseId ) { 
				d=true;
				pw.print("<h3 style='color:crimson'>item already exist in cart<a href='cart.jsp'</a></h3>");
				}
				
			  }
			  if(!d) {
					cartList.add(ct);
					pw.print("Course added in cart");
					response.sendRedirect("course.jsp");
				}
		  }
	
	
	}
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doPost(request, response);
	}

}
