package com.E.learning.entities;

public class checkOut extends Course {
private String name;
private int uid;
private String date;


public  checkOut() {
	
}


public String getName() {
	return name;
}


public void setName(String name) {
	this.name =  name;
}


public int getUid() {
	return uid;
}


public void setUid(int uid) {
	this.uid = uid;
}


public String getDate() {
	return date;
}


public void setDate(String date) {
	this.date = date;
}


public checkOut(int orderId, int uid, String date) {
	super();
	this.name = name;
	this.uid = uid;
	this.date = date;
}
}
