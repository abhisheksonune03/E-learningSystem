package com.E.learning.Userdao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.E.learning.entities.Course;
import com.E.learning.entities.feedback;
import com.E.learning.helper.ConnectionProvider;

public class feedbackdao {
	

public Connection con;


	public int savefeedback(feedback feed) {
		int check=0;
	
		try {
			Connection con=ConnectionProvider.getConnection();
			String query="insert into feedback(name,email,feedback) values(?,?,?)";
			PreparedStatement ps=con.prepareStatement(query);
			ps.setString(1, feed.getName());
			ps.setString(2, feed.getEmail());
			ps.setString(3, feed.getFeedback());
			
			check=ps.executeUpdate();

		}catch(Exception e) {
	 		e.printStackTrace();
		
		}
		return check;
		}
	
	public List<feedback>getAllfeedback(){
		List<feedback>feedback=new ArrayList();
		try {
			Connection con=ConnectionProvider.getConnection();
			PreparedStatement pstmt=null;
			ResultSet rs=null;
			String sql="select name,email,feedback from feedback";
			
			pstmt=con.prepareStatement(sql);
			rs=pstmt.executeQuery();
			while(rs.next())
			{
				feedback f =new feedback();
				f.setName((String)rs.getObject("name"));
				f.setEmail((String)rs.getObject("email"));
				f.setFeedback((String)rs.getObject("feedback"));
				
				feedback.add(f);
			}
			
			 
			  
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return feedback;
		
	}



	public feedback getfeedbackByNameAndEmailAndFeedback(String name, String email, String feedback) {
		// TODO Auto-generated method stub
		return null;
	}



	
		



}
