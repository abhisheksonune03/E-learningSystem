package com.E.learning.Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import com.E.learning.entities.cart;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


public class RemoveServleet extends HttpServlet {
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  
		
		PrintWriter pw=response.getWriter();
		//int  CourseId=Integer.parseInt(request.getParameter("CourseId"));
		String CourseId=request.getParameter("CourseId");
		pw.println("Course Id:"+CourseId);
		if(CourseId!=null) {
			ArrayList<cart>cart_list=(ArrayList<cart>)request.getSession().getAttribute("cart-list");
			  if(cart_list!=null) {
				for(cart c:cart_list) {
					if(c.getCourseId()==Integer.parseInt(CourseId)) {
						cart_list.remove(cart_list.indexOf(c));
						break;
					}
				} 
				response.sendRedirect("cart.jsp");
			}
		}else {
			response.sendRedirect("cart.jsp");
		}
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
