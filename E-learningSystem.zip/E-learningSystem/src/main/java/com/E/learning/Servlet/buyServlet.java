package com.E.learning.Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;

import com.E.learning.entities.Course;
import com.E.learning.entities.checkOut;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class buyServlet extends HttpServlet {
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter pw=response.getWriter();
		SimpleDateFormat formate=new SimpleDateFormat("yyyy-mm-dd");
		Course course=(Course)request.getSession().getAttribute("currentUser");
		 if(course!=null) {
			 String course_name=request.getParameter("course_name");
		 }else {
			 response.sendRedirect("login.jsp");
		 }
		 checkOut check=new checkOut();
		 check.setName(course.toString());
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
