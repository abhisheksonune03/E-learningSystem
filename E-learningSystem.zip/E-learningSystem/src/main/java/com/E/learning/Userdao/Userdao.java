package com.E.learning.Userdao;
import java.sql.*;



import com.E.learning.entities.User; 
public class Userdao {
	
private  Connection con;

public Userdao(Connection con) {
	 
	this.con = con;
} 

public boolean saveUser(User user) {
	boolean f=false;
	try {
		String query="insert into student1(name,email, password,gender) values(?,?,?,?)";
		PreparedStatement ps=this.con.prepareStatement(query);
		ps.setString(1, user.getName());
		ps.setString(2, user.getEmail());
		ps.setString(3, user.getPassword());
		ps.setString(4, user.getGender());
		ps.setString(4, user.getProfile());
		
		ps.executeUpdate();
		f=true;
	}catch(Exception e) {
		e.printStackTrace();
	}
	return f;
}
public   User getUserByEmailAndPassword(String email,String password) {
	User user=null;
	try {
		String query=("Select *  FROM student1 where email=? AND password=?");
		PreparedStatement ps =con.prepareStatement(query);
		ps.setString(1, email);
		ps.setString(2, password);
	
		ResultSet set=ps.executeQuery();
		
		if(set.next()) {
			user =new User();
			String name=set.getString("name");
			user.setName(name);
			user.setId(set.getInt("id"));
			user.setEmail(set.getString("email"));
			user.setPassword(set.getString("password"));
			user.setGender(set.getString("gender"));
			user.setProfile(set.getString("profile"));
	  		
		}
	}catch(Exception e) {
		e.printStackTrace();
		
		} 
		return user;
}


	
	   public  boolean updateUser(User user){
	    	boolean b=false;
	    	//jr he run user ne change nahi kele tr he as its rahil false
		try {
			String query="update student1 set name=?, email=?,password=?,gender=?, profile=? ";
			PreparedStatement ps=con.prepareStatement(query);
			ps.setInt(1, user.getId());
			ps.setString(2, user.getName());
			ps.setString(3, user.getEmail());
			ps.setString(4, user.getPassword());
			ps.setString(5,user.getProfile());
			ps.executeUpdate();
			//jr user ni edit kel tr  boolean true hoil ani changes hotil
			b=true;
		}catch(Exception e) {
			e.printStackTrace();
		}
		return b;
 
	  }
}

