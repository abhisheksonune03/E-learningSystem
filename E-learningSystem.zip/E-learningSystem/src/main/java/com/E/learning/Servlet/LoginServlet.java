package com.E.learning.Servlet;

import java.io.IOException;

import java.io.PrintWriter;
import com.E.learning.Userdao.Userdao;
import com.E.learning.entities.User;
import com.E.learning.helper.ConnectionProvider;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;


/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {

   
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw=response.getWriter();
		
		String userEmail=request.getParameter("email");
		String userPassword=request.getParameter("password");
		Userdao dao=new Userdao(ConnectionProvider.getConnection());  
		User u=dao.getUserByEmailAndPassword(userEmail,userPassword);
		
		if(u==null) {
		//	pw.println("invalid credential ...please Try again");
			Message msg=new Message("invalid credential ...please Try again","error", "alert-denger");
			response.sendRedirect("login.jsp");
			HttpSession s=request.getSession();
			s.setAttribute("msg", msg);
		}else {
			HttpSession s=request.getSession();
			s.setAttribute("currentUser", u);
			response.sendRedirect("course.jsp");
		}
		pw.close();
	}
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

}
